﻿
using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebAccionistas.Negocio;
using WebAccionistas.Entidades;
using System.Data;
using System.Net;
using WebAccionistas.Utilitarios;

namespace WebAccionista.Administracion
{
    public partial class WbfValorNominal : WebAccionistas.Utilitarios.PaginaBase
    {
        private static EValorNominal eVN = new EValorNominal();
        private static NValorNominal nVN = new NValorNominal();
        private String usuarioActual;
        private static String tipoOperacion = "";
        private String mensajeError = Util.SelParametroGeneral("MENSAJE_ERROR_DEFECTO");
        private String pathLog = System.Configuration.ConfigurationManager.AppSettings["PathLog"];


        #region Inicio
        /// <summary>
        /// INICIO Arranca la ejecución del pagina
        /// Solicita el llenar los combos y el grid, así como limpia los campos para ingreso nuevo.
        /// </summary>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["Usuario"] == null)
                {
                    ExpiraSession(this, 1);
                }
                usuarioActual = Session["Usuario"].ToString();
                if (!Page.IsPostBack)
                {
                    RecuperarParametros();
                    llenarListas();

                    ViewState["estado"] = "inicial";
                    PintarBotones();
                }
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - Page_Load :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }

         //   txt_FechaInicial.Attributes.Add(onKeypress, txt_FechaFinal.Focus()  );
        }
        #endregion

        #region Recuperar parametros
        /// <summary>
        /// Recupera parametros Generales
        /// </summary>
        /// <param name="modo"></param>
        void RecuperarParametros()
        {
            try
            {
                DataTable dt_datos = NParametrosGenerales.SelParametrosGenerales();
                if (dt_datos.Rows.Count > 0)
                {
                    imb_nuevo.ImageUrl = dt_datos.Rows[15][1].ToString();
                    imb_eliminar.ImageUrl = dt_datos.Rows[16][1].ToString();
                    imb_cancelar.ImageUrl = dt_datos.Rows[17][1].ToString();
                    imb_imprimir.ImageUrl = dt_datos.Rows[18][1].ToString();
                    imb_exportar.ImageUrl = dt_datos.Rows[19][1].ToString();
                    imb_guardar.ImageUrl = dt_datos.Rows[21][1].ToString();
                    imb_usuario.ImageUrl = dt_datos.Rows[22][1].ToString();
                    imb_buscar.ImageUrl = dt_datos.Rows[24][1].ToString();
                    hfd_lineasGrid.Value = dt_datos.Rows[20][1].ToString();
                }
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - RecuperarParametros :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }
        #endregion

        #region PintarBotones
        /// <summary>
        /// Pone como visible o no visible a los botones del Menu
        /// </summary>
        public void PintarBotones()
        {
            try
            {
                string estado = (string)ViewState["estado"];

                if (estado == "inicial")
                {
                    imb_guardar.Visible = imb_cancelar.Visible = imb_eliminar.Visible = imb_imprimir.Visible = imb_usuario.Visible =imb_exportar.Visible= false;
                    pnl_campos.Visible = false;
                    pnl_busqueda.Visible = true;
                    LlenaGrid();
                 
                }
                if (estado == "nuevo")
                {
                    imb_guardar.Visible = imb_cancelar.Visible = true;
                    pnl_campos.Visible = true;

                    pnl_busqueda.Visible = false;
                    gv_datos.DataSource = null;
                    gv_datos.PageSize = Convert.ToInt32(hfd_lineasGrid.Value.ToString());
                    gv_datos.DataBind();
                    gv_datos.Visible = false;
                    imb_exportar.Visible = false;


                }
                if (estado == "edicion")
                {
                    imb_guardar.Visible = imb_cancelar.Visible = true;
                    pnl_campos.Visible = true;
                    imb_exportar.Visible = false;
                }
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - PintarBotones :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }
        #endregion

        #region Llenar_Listas
        /// <summary>
        /// LLena los combos para la pantalla en modo edición
        /// </summary>
        void llenarListas()
        {
            try
            {
                DataTable dtMoCodigo = NCatalogoTablas.SelCatalogoPersonalizadoPorNombreTabla("ACC_MONEDA");
                if (dtMoCodigo != null)
                    if (dtMoCodigo.Rows.Count > 0)
                    {
                        ddl_Moneda.DataSource = dtMoCodigo;
                        ddl_Moneda.DataValueField = dtMoCodigo.Columns[0].ToString().Trim();
                        ddl_Moneda.DataTextField = dtMoCodigo.Columns[1].ToString().Trim();
                        ddl_Moneda.DataBind();
                        ddl_Moneda.Items.Insert(0, new ListItem("<Escoja una opción>", ""));
                    }
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - llenarListas :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }
        #endregion

        #region Buscar
        /// <summary>
        /// Permite realizar la busqueda por tipo de proceso, despliega el grid con los datos correspondientes a ese tipo de proceo.
        /// Si el tipo de proceso no es escogido recupera todos los registros en el Grid.
        /// </summary>
        protected void imb_buscar_Click(object sender, ImageClickEventArgs e)
        {
           
            try
            {
                if ((txt_FechaInicio.Text != "" && txt_FechaFin.Text == "") || (txt_FechaInicio.Text == "" && txt_FechaFin.Text != ""))
                {
                    PresentarAlerta("Falta un parametro de Busqueda tipo Fecha");
                    gv_datos.DataSource = null;
                    gv_datos.PageSize = Convert.ToInt32(hfd_lineasGrid.Value.ToString());
                    gv_datos.DataBind();
                    
                    gv_datos.Visible = false;
                    imb_cancelar.Visible = true;
                    return;
                }
                else
                {
                    LlenaGrid();
                    Limpiar();
                    imb_cancelar.Visible = true;
                }
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - imb_buscar_Click :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
            
        }
        #endregion

        #region Llena Grid
        /// <summary>
        /// Recupera los registros existentes en la Base de Datos o de acuerdo al periodo de busqueda.
        /// </summary>
        void LlenaGrid()
        {
            try
            {
                if (txt_FechaFin.Text != "" & txt_FechaInicio.Text != "")
                {


                    if (Convert.ToDateTime(txt_FechaFin.Text) > Convert.ToDateTime(txt_FechaInicio.Text))
                    {
                        DataTable dt = NValorNominal.SelValorNominal(txt_FechaInicio.Text, txt_FechaFin.Text);
                        if (dt != null)
                        {
                            gv_datos.DataSource = dt;
                            gv_datos.PageSize = Convert.ToInt32(hfd_lineasGrid.Value.ToString());
                            gv_datos.DataBind();
                           
                            gv_datos.Visible = true;
                            imb_exportar.Visible = true;
                        }
                        else
                        {
                            PresentarAlerta("No existe datos para el criterio de búsqueda");
                            imb_exportar.Visible = false;
                            gv_datos.Visible = false;
                            imb_exportar.Visible = false;
                        }
                    }
                    else
                    {
                        PresentarAlerta("Fechas incorrectas, favor revice que las fecha Inicio sea menor a la fecha Fin");
                        imb_exportar.Visible = false;
                        gv_datos.Visible = false;
                    }
                }
                else
                {
                    DataTable dt = NValorNominal.SelValorNominal("", "");
                    if (dt != null)
                    {
                        gv_datos.DataSource = dt;
                        gv_datos.PageSize = Convert.ToInt32(hfd_lineasGrid.Value.ToString());
                        gv_datos.DataBind();
                        gv_datos.Visible = true;
                        imb_exportar.Visible = true;
                    }
                    else
                    {
                        PresentarAlerta("No existe datos para el criterio de búsqueda");
                        imb_exportar.Visible = false;
                        gv_datos.Visible = false;
                        imb_exportar.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - LlenaGrid :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }

       }
        #endregion

        #region Paginacion
        /// <summary>
        /// Permite avanzar con el siguiente grupo de registros en el Grid.
        /// </summary>
        protected void gv_datos_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                gv_datos.PageIndex = e.NewPageIndex;
                LlenaGrid();
                pnl_campos.Visible = false;
                imb_cancelar.Visible = imb_eliminar.Visible = imb_guardar.Visible= false;
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - gv_datos_PageIndexChanging :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }
        #endregion

        #region Grabar registro
        /// <summary>
        /// Permite guardar el registro nuevo en la Base de Datos, esta función no permite modificar ni eliminar registros.
        /// </summary>
        protected void imb_guardar_Click(object sender, ImageClickEventArgs e)
        {
         try
            {
            if (vnCodigo.Value == "")
                vnCodigo.Value = "0";

            if (ddl_Moneda.SelectedIndex != 0)
            {
                eVN.v_VN_CODIGO = Convert.ToDouble(vnCodigo.Value);
                eVN.v_VN_FECHA_INICIAL = txt_FechaInicial.Text;
                eVN.v_VN_FECHA_FINAL = txt_FechaFinal.Text;
                eVN.v_VN_MONEDA = ddl_Moneda.SelectedItem.Value;
                eVN.v_VN_VALOR_NOMINAL = Convert.ToDecimal(txt_ValorNominal.Text);
                

                DataTable dt = NValorNominal.InsUpdDatosValorNominal(eVN);
                
                GrabaAuditoria(tipoOperacion);

                LlenaGrid();
                Limpiar();
                PresentarAlerta(dt.Rows[0][0].ToString());
                ViewState["estado"] = "inicial";
                PintarBotones();
            }
            else
                PresentarAlerta("No existen datos para actualizar ... Presione el boton NUEVO");
            }
         catch (Exception ex)
         {
             StringBuilder log = new StringBuilder();
             log.Append("WbfValorNominal.aspx.cs - imb_guardar_Click :");
             log.Append(ex.Message);
             Util.EscribirLog(pathLog, log.ToString());
             PresentarAlerta(mensajeError);
         }

        }
        #endregion

        #region exportar a Excel
        /// <summary>
        /// Permite exportar la información del Grid a EXCEL
        /// </summary>
        protected void imb_exportar_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                string filtro1 = txt_FechaInicio.Text;
                string filtro2 = txt_FechaFin.Text;

                DataSet dsResultado = NValorNominal.SelValorNominal(filtro1, filtro2).DataSet;
                Session["dtExcel"] = dsResultado.Tables[0];
                Server.Transfer("../Exportar/ExportarExcel.aspx", false);               
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - imb_exportar_Click :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }

        #endregion

        #region Limpiar Campos
        /// <summary>
        /// Permite limpiar los campos para ingresar un nuevo registro.
        /// </summary>
        void Limpiar()
        {
            try
            {
                ddl_Moneda.ClearSelection();
                txt_ValorNominal.Text = string.Empty;
                txt_FechaInicial.Text = string.Empty;
                txt_FechaFinal.Text = string.Empty;
                //txt_FechaInicio.Text = string.Empty;
                //txt_FechaFin.Text = string.Empty;
     
                vnCodigo.Value = string.Empty;
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - Limpiar :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }
        #endregion

        #region Presentar Alerta
        /// <summary>
        /// Presenta el MSG de alerta por proceso erorróneo o proceso satisfactorio.
        /// </summary>
      private void PresentarAlerta(String mensaje)
        {
            try
            {
                string strPagina = mensaje;
                string strCad = "<script>presenta_alerta('" + Convert.ToString(strPagina) + "');</script>";
                ClientScript.RegisterStartupScript(GetType(), "nombre", strCad);
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - PresentarAlerta :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }
        #endregion

        #region Nuevo
        /// <summary>
        /// Prepara la ventana para un nuevo campo
        /// </summary>
       protected void imb_nuevo_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                Limpiar();
                tipoOperacion = "INS";
                ViewState["estado"] = "nuevo";
                PintarBotones();
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - imb_nuevo_Click :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }
        #endregion

        #region Cancelar
        /// <summary>
        /// Cancela el proceso, limpia los campos ingresados o recueprados
        /// </summary>
       protected void imb_cancelar_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                txt_FechaInicio.Text = string.Empty;
                txt_FechaFin.Text = string.Empty;
                Limpiar();
                ViewState["estado"] = "inicial";
                PintarBotones();
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - imb_cancelar_Click :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }
        #endregion

        #region Editar datos del Grid
        /// <summary>
        /// Edita campos para ser modificados o eliminados (cambiando estado a inactivo)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GV_datos_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                ViewState["estado"] = "edicion";
                PintarBotones();
                tipoOperacion = "UPD";
  
                if (e.CommandName == "Select")
                {
                    gv_datos.SelectedIndex = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = gv_datos.SelectedRow;
                    vnCodigo.Value = row.Cells[0].Text;
                    pnl_campos.Visible = true;
                    txt_FechaInicial.Text = row.Cells[1].Text;
                    txt_FechaFinal.Text  = row.Cells[2].Text;
                    ddl_Moneda.SelectedValue = row.Cells[3].Text;
                    txt_ValorNominal.Text = row.Cells[5].Text;
                   
                    pnl_busqueda.Visible = false;
                   


                }
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - GV_datos_RowCommand :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }
        #endregion

        #region Graba Auditoria

        /// <summary>
        /// Graba el registro de Auditoria
        /// Si presiona el Botón NUEVO    el tipo de operación se registrs con I
        /// Si Presiona el botón EDITAR   el tipo de operación se registra con U
        /// Si Presiona el botón ELIMINAR el tipo de operación se registra con D
        /// </summary>
        /// <param name="tipo" />
        private void GrabaAuditoria(string tipo)
        {
            try
            {
                string ip = Session["IpCliente"].ToString();
                const string tabla = "ACC_VALOR_NOMINAL";
                const string proceso = "Mantenimiento de Valor Nominal";
                StringBuilder sb = new StringBuilder();

                sb.Append("Codigo : ");
                sb.Append(vnCodigo.Value.ToString());
                sb.Append("|");
                sb.Append("Fecha Inicial : ");
                sb.Append(txt_FechaInicial.Text.ToString());
                sb.Append("|");
                sb.Append("Fecha Final : ");
                sb.Append(txt_FechaFinal.Text.ToString());
                sb.Append("|");
                sb.Append("Moneda : ");
                sb.Append(ddl_Moneda.SelectedItem.Text.ToString());
                sb.Append("|");
                sb.Append("Valor Nominal : ");
                sb.Append(txt_ValorNominal.Text.ToString());
                DataTable dt = NUtil.InsUdpAuditoria(usuarioActual, tipo, ip, tabla, proceso, sb.ToString());
                //PresentarAlerta(dt.Rows[0][0].ToString());
            }
            catch (Exception ex)
            {
                StringBuilder log = new StringBuilder();
                log.Append("WbfValorNominal.aspx.cs - GrabaAuditoria :");
                log.Append(ex.Message);
                Util.EscribirLog(pathLog, log.ToString());
                PresentarAlerta(mensajeError);
            }
        }
        #endregion

      
    }
}